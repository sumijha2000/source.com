import React from 'react'
import './Navbar.css'
import logo from '../../assets/logo.svg'

const Navbar = () => {
  return (
    <nav className='container'>
        <img src={logo} alt="logo" className='logo' />
        <ul>
            <li>Home</li>
            <li>About Us</li>
            <li>Blog-News</li>
            <li>Contact</li>
            <input type="text" placeholder='Search'/>
        </ul>
    </nav>
  )
}

export default Navbar